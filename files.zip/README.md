# Multi-Sheet Telegram Bot

A powerful Telegram bot that reads your Google Sheets and analyzes data using Claude AI.

## Features

✅ Read data from Google Sheets
✅ Analyze data with Claude AI
✅ Answer questions about your data
✅ Works 24/7 on Railway
✅ Your laptop can be OFF!

## Quick Start

1. **Clone/Download this repository**
2. **Copy all files to a folder**
3. **Push to GitHub**
4. **Deploy on Railway**
5. **Test on Telegram**

## Files

- `.env` - Your credentials (keep secret!)
- `package.json` - Dependencies
- `index.js` - Bot code
- `.gitignore` - Protect .env from GitHub
- `README.md` - This file

## Setup

### Step 1: Add Files to GitHub

```
1. Create new GitHub repo
2. Add all 5 files
3. Commit and push
```

### Step 2: Deploy to Railway

```
1. Go to Railway.app
2. New Project → Deploy from GitHub
3. Select your repo
4. Add Variables (copy from .env)
5. Deploy!
```

### Step 3: Test

```
Open Telegram
Search for your bot
Send: /start
Ask: "How many jars were delivered on 7th of March?"
```

## Environment Variables

All variables are in `.env` file - copy them to Railway Variables.

## Commands

- `/start` - Start bot
- `/help` - Show help
- Or just ask questions!

## Support

Check Railway logs if something goes wrong.

## License

MIT
