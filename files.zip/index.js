const { Telegraf } = require('telegraf');
const axios = require('axios');
const { google } = require('googleapis');
const dotenv = require('dotenv');

dotenv.config();

console.log('🚀 Bot starting...');

const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN);
const USER_ID = parseInt(process.env.TELEGRAM_USER_ID);

const auth = new google.auth.GoogleAuth({
  credentials: {
    type: 'service_account',
    project_id: process.env.GOOGLE_PROJECT_ID,
    private_key_id: process.env.GOOGLE_PRIVATE_KEY_ID,
    private_key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, '\n'),
    client_email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
    client_id: process.env.GOOGLE_CLIENT_ID,
    auth_uri: 'https://accounts.google.com/o/oauth2/auth',
    token_uri: 'https://oauth2.googleapis.com/token',
  },
  scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
});

const sheets = google.sheets({ version: 'v4', auth });

async function getSheetData() {
  try {
    console.log('📖 Reading Google Sheet...');
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: process.env.GOOGLE_SHEET_ID_1,
      range: 'Daily Metrics!A:Z',
    });
    
    const data = response.data.values || [];
    console.log(`✅ Sheet read successfully (${data.length} rows)`);
    return data;
  } catch (error) {
    console.error('❌ Error reading sheet:', error.message);
    return [];
  }
}

async function analyzeWithClaude(question, sheetData) {
  try {
    if (!sheetData || sheetData.length === 0) {
      return 'No data available in sheet';
    }

    console.log('🧠 Sending data to Claude...');

    const headers = sheetData[0] || [];
    let formattedData = `Columns: ${headers.join(', ')}\n\nData:\n`;
    
    sheetData.slice(1, 20).forEach((row, index) => {
      formattedData += `Row ${index + 1}: ${row.join(' | ')}\n`;
    });

    const response = await axios.post(
      'https://api.anthropic.com/v1/messages',
      {
        model: 'claude-opus-4-20250805',
        max_tokens: 1024,
        messages: [
          {
            role: 'user',
            content: `You are analyzing data from a Google Sheet.\n\nSheet Data:\n${formattedData}\n\nUser Question: ${question}\n\nProvide a clear, concise answer based on the data.`
          }
        ]
      },
      {
        headers: {
          'x-api-key': process.env.CLAUDE_API_KEY,
          'anthropic-version': '2023-06-01',
          'content-type': 'application/json'
        }
      }
    );

    if (response.data && response.data.content && response.data.content[0]) {
      const answer = response.data.content[0].text;
      console.log('✅ Claude responded');
      return answer;
    }

    return 'Claude did not return a response';
  } catch (error) {
    console.error('❌ Claude error:', error.message);
    if (error.response?.data) {
      console.error('Error details:', JSON.stringify(error.response.data));
    }
    return `Error: ${error.message}`;
  }
}

bot.start((ctx) => {
  if (ctx.from.id !== USER_ID) {
    return ctx.reply('❌ Not authorized');
  }
  console.log(`👤 User ${ctx.from.first_name} started bot`);
  ctx.reply('👋 Hello! I can analyze your Daily Metrics data. Ask me anything!');
});

bot.help((ctx) => {
  if (ctx.from.id !== USER_ID) {
    return ctx.reply('❌ Not authorized');
  }
  ctx.reply('📚 Commands:\n/start - Start\n/help - This help\n\nOr ask any question about your data!');
});

bot.on('text', async (ctx) => {
  if (ctx.from.id !== USER_ID) {
    return ctx.reply('❌ Not authorized');
  }

  if (ctx.message.text.startsWith('/')) {
    return;
  }

  try {
    console.log(`💬 User asked: "${ctx.message.text}"`);
    
    await ctx.sendChatAction('typing');
    
    const sheetData = await getSheetData();
    const answer = await analyzeWithClaude(ctx.message.text, sheetData);
    
    ctx.reply(answer);
  } catch (error) {
    console.error('Error:', error.message);
    ctx.reply(`❌ Error: ${error.message}`);
  }
});

bot.catch((err) => {
  console.error('🚨 Bot error:', err);
});

console.log('🚀 Launching bot with polling...');

bot.launch({
  polling: {
    timeout: 30,
    limit: 100,
    allowedUpdates: ['message']
  }
});

console.log('✅ Bot is LIVE!');

process.on('SIGINT', () => {
  console.log('🛑 Stopping bot...');
  bot.stop('SIGINT');
});

process.on('SIGTERM', () => {
  console.log('🛑 Stopping bot...');
  bot.stop('SIGTERM');
});
